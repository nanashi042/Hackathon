
  # Anonymous Support Web App

  This is a code bundle for Anonymous Support Web App. The original project is available at https://www.figma.com/design/Mn0h1xs76Txqd8lm33NJQN/Anonymous-Support-Web-App.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  